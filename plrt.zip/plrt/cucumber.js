export default {
  default: {
    import: [
      './step-definitions/login.steps.js',
      './support/hooks.js',
      './support/world.js',
    ],
     timeout: 30000,
    format: ['progress', 'html:reports/cucumber-report.html'],
    paths: ['features/**/*.feature'],
  },
};