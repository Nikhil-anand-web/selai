Feature: Naukri Login

  Scenario: Successful login
    Given I am on the Naukri homepage
    When I login with username "na52m2002@gmail.com" and password "7070514195.ccs"
    Then I should be redirected to the homepage