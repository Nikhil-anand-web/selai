import { test as base, expect } from '@playwright/test';
import { HomePage } from './pages/HomePage.js';
import SearchBar from './global_ui_elements/SearchBar.js';

export const test = base.extend({
  homePage: async ({ page }, use) => {
    await use(new HomePage(page));
  },
  searchBar: async ({ page }, use) => {
    await use(new SearchBar(page));
  }
 
});

export { expect };