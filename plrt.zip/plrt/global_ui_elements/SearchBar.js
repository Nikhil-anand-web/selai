import { BasePage } from "../pages/BasePage";

export default class SearchBar extends BasePage {
  constructor(page) {
    super(page);
    this.page = page;
    this.searchEnabler = page.locator('#ni-gnb-searchbar button').nth(0);
    this.searchInput = page.locator('//input[@class ="suggestor-input " and @placeholder ="Enter keyword / designation / companies" ]');
    this.searchButton = page.locator('//button/span[text() = "Search"]/parent::button');
  }

    async search(query) {
        await this.isVisible(this.searchEnabler);
      await this.searchEnabler.click();
     await this.isVisible(this.searchInput);
      await this.fill(this.searchInput, query);
      await this.click(this.searchButton);
    }


};