import { BasePage } from './BasePage.js';

export class HomePage extends BasePage {
  constructor(page) {
    super(page);
    this.url = 'https://www.naukri.com/';
    this.loginBtn = page.locator("#login_Layer");
    this.userNameField = page.locator("//div[@class=\"form-row\"]/input[@type='text']")
    this.passwordField = page.locator("//div[@class=\"form-row\"]/input[@type='password']")
    this.loginBtnSubmit = page.locator(".btn-primary.loginButton")

  }

  async navigate() {
    await super.goto(this.url);
  }

  async login(userName , password) {
   await this.loginBtn.click();
    await this.userNameField.waitFor({ state: 'visible' , timeout: 10000 }); 
    await this.userNameField.fill(userName);
    await this.passwordField.fill(password);
    await this.loginBtnSubmit.click(); // only once
  }
}