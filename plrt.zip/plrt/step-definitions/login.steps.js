import { Given, When, Then } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { HomePage } from '../pages/HomePage.js';

Given('I am on the Naukri homepage', async function () {
  this.homePage = new HomePage(this.page);
  await this.homePage.navigate();
});

When('I login with username {string} and password {string}', async function (username, password) {
  await this.homePage.login(username, password);
  await this.page.waitForURL('**/mnjuser/homepage');
});

Then('I should be redirected to the homepage', async function () {
  await expect(this.page).toHaveURL('https://www.naukri.com/mnjuser/homepage');
});