import { setWorldConstructor, World } from '@cucumber/cucumber';

class CustomWorld extends World {
  constructor(options) {
    super(options);
    this.page = null;
    this.context = null;
  }
}

setWorldConstructor(CustomWorld);