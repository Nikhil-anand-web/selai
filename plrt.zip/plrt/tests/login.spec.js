// @ts-check
import { test, expect } from '../fixtures.js';

test('login test', async ({ page ,homePage }) => {
   await homePage.navigate();
  await homePage.login("na52m2002@gmail.com","7070514195.ccs")
  await expect(page).toHaveURL("https://www.naukri.com/mnjuser/homepage");
});


