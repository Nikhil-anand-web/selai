// @ts-check
import { test, expect } from '../fixtures.js';

test('search test', async ({ page ,homePage ,searchBar }) => {
   await homePage.navigate();
   await homePage.login("na52m2002@gmail.com","7070514195.ccs")
   await searchBar.search("SDET");
});


